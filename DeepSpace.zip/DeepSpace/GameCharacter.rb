module Deepspace
	module GameCharacter
		 SPACESTATION=:spacestation
		 ENEMYSTARSHIP=:enemystarship
	end
end
