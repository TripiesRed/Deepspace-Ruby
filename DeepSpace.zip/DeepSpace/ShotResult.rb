module Deepspace
	module ShotResult
		 DONOTRESIST=:donotresist
		 RESIST=:resist
	end
end
